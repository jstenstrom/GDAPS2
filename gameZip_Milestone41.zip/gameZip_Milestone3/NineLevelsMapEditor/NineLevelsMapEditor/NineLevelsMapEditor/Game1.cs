﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NineLevelsMapEditor
{
    // Create a state enum
    public enum State { PLAY, FREEZE}

    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        // State of the application
        public static State state = State.PLAY;
        public static GraphicsDeviceManager graphics;
        public static SpriteBatch spriteBatch;

        // Client bounds
        public static Vector2 clientBounds;

        // Globals
        public static bool quit = false;
        public static Vector2 drawOffset = Vector2.Zero;

        // File names
        public static string mapName;
        public static string fileName;
        public static string loadFileName;
        public static string tileSheetFileName;

        // Variable to hold the drawable layer
        public static int drawableLayer = 0;

        // Map
        public static Map_Classes.Map map;

        // Map and tile dimensions
        public static int mapHeight = 15;
        public static int mapWidth = 20;
        public static int tileHeight = 32;
        public static int tileWidth = 32;

        // Selected tile number
        public static int selectedTileNum = 0;

        // Textures
        public static Texture2D tileSheet;
        public static Texture2D solid;
        Texture2D pixel;

        // Input states
        MouseState curState;
        KeyboardState prevState;

        // Font
        SpriteFont basic;

        // GUI
        GUI.HUD hud;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            //Initialize map
            map = new Map_Classes.Map(mapWidth, mapHeight, tileWidth, tileHeight);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // Make the mouse visible
            this.IsMouseVisible = true;

            // Set the window size
            graphics.PreferredBackBufferHeight = 700;
            graphics.PreferredBackBufferWidth = 800;
            graphics.ApplyChanges();

            // Initialize the client bounds
            clientBounds = new Vector2(Window.ClientBounds.Width, Window.ClientBounds.Height);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // Load textures and SpriteFont
            pixel = Content.Load<Texture2D>("pixel");
            solid = Content.Load<Texture2D>("solid");
            basic = Content.Load<SpriteFont>("Arial");
            
            // Intilialize the HUD
            hud = new NineLevelsMapEditor.GUI.HUD(Content);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (quit)
                Exit();

            // Update the map title
            this.Window.Title = "Map Editor - " + mapName;

            // Update the selected tile - operated by up and down arrow keys
            KeyboardState keyState = Keyboard.GetState();
            if (selectedTileNum < map.tileSet.Count - 1)
            {
                if (keyState.IsKeyDown(Keys.Up) && !prevState.IsKeyDown(Keys.Up))
                {
                    selectedTileNum++;
                }
            }
            if (selectedTileNum > 0)
            {
                if (keyState.IsKeyDown(Keys.Down) && !prevState.IsKeyDown(Keys.Down))
                {
                    selectedTileNum--;
                }
            }

            //Get input from the mouse
            if (state == State.PLAY && tileSheet != null)
            {
                if (drawableLayer == 0)
                {
                    map.tileLayer1.SetTiles(selectedTileNum + 1);
                }
                else if (drawableLayer == 1)
                {
                    map.tileLayer2.SetTiles(selectedTileNum + 1);
                }
                else if (drawableLayer == 2)
                {
                    map.solidLayer.SetTiles(1);
                }
            }

            // Update the current mouse state
            curState = Mouse.GetState();

            // Update the keyboard state
            prevState = keyState;

            // Update scroll values
            map.UpdateUserInput();

            // Update the HUD
            hud.Update();

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // Begin the spritebatch call
            spriteBatch.Begin();

            // Draw map bounds
            spriteBatch.Draw(pixel, new Rectangle(-(int)drawOffset.X * map.tileWidth, -(int)drawOffset.Y * map.tileHeight, map.mapWidth * map.tileWidth, map.mapHeight * map.tileHeight), Color.White);

            // Draw the map
            map.DrawMap();

            // Draw the HUD
            hud.Draw();

            // Draw the selected tile overlay
            if (tileSheet != null && drawableLayer != 2)
            {
                spriteBatch.Draw(tileSheet, new Vector2(curState.X - tileWidth / 2, curState.Y - tileWidth / 2), map.tileSet[selectedTileNum], Color.White);
            }

            // Show the user which tile they are drawing on
            string layerText = "";

            if (drawableLayer == 0)
            {
                layerText = "Layer 1";
            }
            if (drawableLayer == 1)
            {
                layerText = "Layer 2";
            }
            if (drawableLayer == 2)
            {
                layerText = "Collision Layer";
            }

            spriteBatch.DrawString(basic, layerText, new Vector2(5, 5), Color.White);

            base.Draw(gameTime);

            // End the spritebatch call
            spriteBatch.End();
        }
    }
}
