﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace Stenstrom_HW2
{
    class GameObject
    {
        //attributes
        Rectangle rec;
        Texture2D texture;
        Texture2D textureAction;
        //properties to get attributes
        public Texture2D Texture { get { return texture; } set { texture = value; } }
        public Texture2D TextureAction { get { return textureAction; } set { textureAction = value; } }
        public Rectangle Rec { get { return rec; } }
        public int PosX { get { return rec.X; } set { rec.X = value; } }
        public int PosY { get { return rec.Y; } set { rec.Y = value; } }

        //constructor
        public GameObject(int x, int y, int width, int height)
        {
            rec = new Rectangle(x, y, width, height);
        }

        //draw method for object to draw itself
        public virtual void Draw(SpriteBatch image)
        {
            image.Draw(texture, rec, Color.White);
        }
        //rec = new Rectangle(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2, 40, 40);
        public void DrawAction(SpriteBatch imageAct)
        {
            imageAct.Draw(textureAction, rec, Color.White);
        }
    }
}
