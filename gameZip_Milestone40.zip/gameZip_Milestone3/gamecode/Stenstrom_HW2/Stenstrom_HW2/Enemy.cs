﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Stenstrom_HW2
{
    class Enemy:GameObject
    {
        //boolean to tell if active
        Boolean active;
        //property
        public Boolean Active { get { return active; } set { active = value; } }

        //constuctor
        public Enemy(int x, int y, int width, int height)
            : base(x, y, width, height)
        {
            active = true;
        }

        //method to check collsion
        public Boolean CheckCollision(GameObject go)
        {
            //if objects intersect collsion true else collsion false
            if (active == true)
            {
                if (this.Rec.Intersects(go.Rec))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        //override draw method
        public override void Draw(SpriteBatch image)
        {
            if (active == true)
            {
                base.Draw(image);
            }
        } 
    }
}
