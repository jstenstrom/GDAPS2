﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NineLevelsMapEditor.Forms
{
    public partial class LoadMapForm : Form
    {
        // Load file name
        string loadFileName;

        public LoadMapForm()
        {
            InitializeComponent();
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            // Set the initial directory
            openFileDialog1.InitialDirectory = @"C:\";

            // Set the title
            openFileDialog1.Title = "Select a map file";
            openFileDialog1.FileName = "";

            // Filter for only text files
            openFileDialog1.Filter = "Text Files (*.txt) | *.txt";
            openFileDialog1.FilterIndex = 1;

            // Load the map
            if (openFileDialog1.ShowDialog() != DialogResult.Cancel)
            {
                loadFileName = openFileDialog1.FileName;
                fileNameTextBox.Text = loadFileName;
            }
            else
            {
                loadFileName = "";
            }

        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            // Show cancel dialog result
            this.DialogResult = DialogResult.Cancel;
        }

        private void okayButton_Click(object sender, EventArgs e)
        {
            // Check that a file sheet has been loaded before the map file is
            if (Game1.tileSheetFileName != null)
            {
                Game1.map.LoadMap(loadFileName);
            }
            else
            {
                MessageBox.Show("Please load a tile set before trying to load a map.");
            }

            // Update the map size and tile dimensions
            Game1.mapHeight = Game1.map.mapHeight;
            Game1.mapWidth = Game1.map.mapWidth;
            Game1.tileHeight = Game1.map.tileHeight;
            Game1.tileWidth = Game1.map.tileWidth;
            Game1.map = new Map_Classes.Map(Game1.mapWidth, Game1.mapHeight, Game1.tileWidth, Game1.tileHeight);

            // Load the map
            Game1.map.LoadMap(loadFileName);

            // Reload the tileset
            Game1.map.LoadTileSet(Game1.tileSheet);

            // Show the OK dialog result
            this.DialogResult = DialogResult.OK;
        }
    }
}
