﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NineLevelsMapEditor.Map_Classes
{
    public class Map
    {
        // Map and tile size variables
        public int mapWidth;
        public int mapHeight;
        public int tileWidth;
        public int tileHeight;
        
        // New layers
        public Layer tileLayer1;
        public Layer tileLayer2;
        public Layer solidLayer;

        // Rectangle list to hold the tile bounds
        public List<Rectangle> tileSet = new List<Rectangle>();

        // Rectangle to temporarily hold tile bounds
        Rectangle bounds;

        // Constructor
        public Map(int mWid, int mHgt, int tWid, int tHgt)
        {
            mapWidth = mWid;
            mapHeight = mHgt;
            tileWidth = tWid;
            tileHeight = tHgt;

            tileLayer1 = new Layer(mapWidth, mapHeight, tileWidth, tileHeight);
            tileLayer2 = new Layer(mapWidth, mapHeight, tileWidth, tileHeight);
            solidLayer = new Layer(mapWidth, mapHeight, tileWidth, tileHeight);
        }

        public void UpdateUserInput()
        {
            // Move the viewable map using WASD
            KeyboardState kState = Keyboard.GetState();
            if (Game1.drawOffset.X > 0)
            {
                if (kState.IsKeyDown(Keys.D))
                {
                    Game1.drawOffset.X -= 1;
                }
            }
            else if (Game1.drawOffset.X < mapWidth - 1)
            {
                if (kState.IsKeyDown(Keys.A))
                {
                    Game1.drawOffset.X += 1;
                }
            }
            else if (Game1.drawOffset.Y > 0)
            {
                if (kState.IsKeyDown(Keys.S))
                {
                    Game1.drawOffset.Y -= 1;
                }
            }
            else if (Game1.drawOffset.Y < mapHeight - 1)
            {
                if (kState.IsKeyDown(Keys.W))
                {
                    Game1.drawOffset.Y += 1;
                }
            }
        }

        public void SaveMap(string fileName)
        {
            try
            {
                // Create and initialize the stream writer object
                StreamWriter objWriter = new StreamWriter(fileName + ".txt");

                // Write out the map and tile dimensions
                objWriter.WriteLine(mapWidth);
                objWriter.WriteLine(mapHeight);
                objWriter.WriteLine(tileWidth);
                objWriter.WriteLine(tileHeight);

                // Write the layers to the text file
                tileLayer1.SaveLayer(objWriter);
                tileLayer2.SaveLayer(objWriter);
                solidLayer.SaveLayer(objWriter);

                // Close file amd dispose of graphics object
                objWriter.Close();
                objWriter.Dispose();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There was an error saving the map.\nError: " + ex);
            }
        }

        public void LoadMap(string fileName)
        {
            try
            {
                // Create and initialize a stream reader object
                StreamReader objReader = new StreamReader(fileName + ".txt");

                // Read map and tile sizes from file
                mapWidth = Convert.ToInt32(objReader.ReadLine());
                mapHeight = Convert.ToInt32(objReader.ReadLine());
                tileWidth = Convert.ToInt32(objReader.ReadLine());
                tileHeight = Convert.ToInt32(objReader.ReadLine());

                // Reinitialize the map layers
                tileLayer1 = new Layer(mapWidth, mapHeight, tileWidth, tileHeight);
                tileLayer2 = new Layer(mapWidth, mapHeight, tileWidth, tileHeight);
                solidLayer = new Layer(mapWidth, mapHeight, tileWidth, tileHeight);

                // Load layers
                tileLayer1.LoadLayer(objReader);
                tileLayer2.LoadLayer(objReader);
                solidLayer.LoadLayer(objReader);

                // Close file and dispose of object
                objReader.Close();
                objReader.Dispose();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There was an error loading the map. Is the map file a valid file?\nError: " + ex);
            }
        }

        public void DrawMap()
        {
            try
            {
                // Loop through all tile positions
                for (int x = 0; x < mapHeight; x++)
                {
                    for (int y = 0; y < mapWidth; y++)
                    {
                        //Tile Layer 1
                        if (tileLayer1.layer[y, x] != 0)
                        {
                            //Get the tile
                            bounds = tileSet[tileLayer1.layer[y, x] - 1];

                            //Draw the tile
                            Game1.spriteBatch.Draw(Game1.tileSheet, new Vector2(((y - Game1.drawOffset.X) * tileWidth), ((x - Game1.drawOffset.Y) * tileHeight)), bounds, Color.White);
                        }

                        //Tile Layer 2
                        if (tileLayer2.layer[y, x] != 0)
                        {
                            //Get the tile
                            bounds = tileSet[tileLayer2.layer[y, x] - 1];

                            //Draw the tile
                            Game1.spriteBatch.Draw(Game1.tileSheet, new Vector2(((y - Game1.drawOffset.X) * tileWidth), ((x - Game1.drawOffset.Y) * tileHeight)), bounds, Color.White);
                        }

                        //Solid Layer
                        if (solidLayer.layer[y, x] != 0)
                        {
                            //Draw it in screen space
                            Game1.spriteBatch.Draw(Game1.solid, new Vector2(((y - Game1.drawOffset.X) * tileWidth), ((x - Game1.drawOffset.Y) * tileHeight)), new Rectangle(0, 0, tileWidth, tileHeight), new Color(255, 255, 255, 100));
                        }
                    }
                }
            }
            catch
            {

            }
        }

        public void LoadTileSet(Texture2D tileSheet)
        {
            //Get tile dimensions
            int numOfTilesX = (int)tileSheet.Width / tileWidth;
            int numOfTilesY = (int)tileSheet.Height / tileHeight;

            //Initialize the tile set list
            tileSet = new List<Rectangle>(numOfTilesX = numOfTilesY);

            //Get the bounds of all tiles in sheet
            for (int j = 0; j < numOfTilesY; j++)
            {
                for (int i = 0; i < numOfTilesX; i++)
                {
                    bounds = new Rectangle(i * tileWidth, j * tileHeight, tileWidth, tileHeight);
                    tileSet.Add(bounds);
                }
            }
        }
    }
}
