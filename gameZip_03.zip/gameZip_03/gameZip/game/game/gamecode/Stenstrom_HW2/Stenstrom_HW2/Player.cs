﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Stenstrom_HW2
{
    class Player:GameObject
    {
        //new attributes to control score
        int levelScore,totalScore;
        //public properties to get and set these values
        public int LevelScore { get { return levelScore; } set { levelScore = value;} }
        public int TotalScore { get { return totalScore; } set { totalScore = value; } }
        //constructor
        public Player(int lvlScore, int ttlScore,int x, int y, int width, int height)
            : base(x, y, width, height)
        {
            lvlScore = 0;
            ttlScore = 0;
        }
        public override void Draw(SpriteBatch image)
        {
            base.Draw(image);
        }
    }
}
