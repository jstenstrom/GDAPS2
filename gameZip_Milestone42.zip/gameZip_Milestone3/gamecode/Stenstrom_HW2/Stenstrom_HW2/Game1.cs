﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
/*Jacob Stenstrom
 * Homework 2*/
namespace Stenstrom_HW2
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        //attributes defined for what is needed
        Texture2D demonSprite, demonSprite2,demonSprite3;
        Texture2D redRectangle;
        Texture2D bernBegin;
        Texture2D bernGameOver;
        Texture2D background;
        //Texture2D block;
        Texture2D stand;
        Texture2D attack;
        int lives;
        
        SpriteFont font1;
        Rectangle rec,recObject,recBackground,bernStartRec,platform1,platform2,platform3;//bernEnd;
        enum GameState { Menu, Game, GameOver };
        enum CharacterState { Stand, Action, Jump };
        GameState gState;
        CharacterState cState;
        Player character;
        List<Enemy> grab;
        Platform[] platforms;
        int level;
        double timer;
        KeyboardState kbState;
        KeyboardState previousKbState;
        Random rand = new Random();
        int gravity;
        bool jumping;
        int jumpspeed;
        int ground;
        Rectangle bottom;
        int wait;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            //gState = GameState.Menu;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            //creates the attributes needed
            grab = new List<Enemy>();
            platforms = new Platform[10];
            character = new Player(0, 0, GraphicsDevice.Viewport.Height/2, 350, 55, 55);
            recBackground = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            platforms[0] = new Platform(50,50,50,50);
            platforms[1] = new Platform(50, 100, 20, 20);
            platforms[2] = new Platform(500, 100, 20, 20);
            platforms[3] = new Platform(50,100,200,50);
            platforms[4] = new Platform(500, 100, 200, 50);
            platforms[5] = new Platform(750, 150, 200, 50);
            platforms[6] = new Platform(50, 200, 100, 50);
            platforms[7] = new Platform(500, 50, 200, 50);
            platforms[8] = new Platform(20, 150, 200, 50);
            platforms[9] = new Platform(600, 50, 200, 50);
            bernStartRec = new Rectangle(0, 0, 350, 350);
            lives = 3;
            gravity = 1;
            jumping = false;
            jumpspeed = 0;
            ground = character.PosY;
            wait = 0;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            //loading all content needed for game from content folder
            font1 = Content.Load<SpriteFont>("Font1");
            demonSprite = Content.Load<Texture2D>("demon");
            demonSprite2=Content.Load<Texture2D>("skel");
            demonSprite3 = Content.Load<Texture2D>("demon_4");
            stand = Content.Load<Texture2D>("sprite_1_png");
            attack = Content.Load<Texture2D>("sprite_2_action");
            character.Texture = stand;
            character.TextureAction=attack;
            redRectangle = Content.Load<Texture2D>("redrectangle");
            background = Content.Load<Texture2D>("america");
            bernBegin = Content.Load<Texture2D>("bernieCamp");
            bernGameOver = Content.Load<Texture2D>("sadBurn");
            foreach (Platform platform in platforms)
            {
                platform.Texture = redRectangle;
            }
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            
            // TODO: Add your update logic here
            //if state is menu and enter is pressed change state
            if (gState == GameState.Menu)
            {
                previousKbState = kbState;
                kbState = Keyboard.GetState();
                if (SingleKeyPress(Keys.Enter)==true)
                {
                    
                    gState = GameState.Game;
                    ResetGame();
                }
            }
            //game state
            if (gState == GameState.Game)
            {
                
                previousKbState = kbState;
                kbState = Keyboard.GetState();
                cState = CharacterState.Stand;
                bottom = new Rectangle(0, 400, 800, 100);
                /*platforms[0] = new Platform(50, 100, 20, 20);
                platforms[1] = new Platform(500, 100, 20, 20);*/
                //changes timer
                timer -= gameTime.ElapsedGameTime.TotalSeconds;
                double startJump = timer;
                character.PosY += gravity;
                //checks keys and move character
                
                if (kbState.IsKeyDown(Keys.W) == true)
                {
                    jumping = true;
                    jumpspeed = -18;
                    

                  
                }
                if (jumping)
                {
                    character.PosY += jumpspeed;
                    jumpspeed += gravity;
                    
                }
                if (character.PosY >= ground)
                    {
                        character.PosY = ground;
                        jumping = false;
                    }
              
                if (kbState.IsKeyDown(Keys.A) == true)
                {
                    character.PosX -= 4;
                }
                /*if (kbState.IsKeyDown(Keys.S) == true)
                {
                    character.PosY += 2;
                }*/
                if (kbState.IsKeyDown(Keys.D) == true)
                {
                    character.PosX += 4;
                }
                if (kbState.IsKeyDown(Keys.Space) == true)
                {
                    //character.PosY -= 2;
                    cState = CharacterState.Action;
                }
                //screen wrap method to make character wrap around screen
                ScreenWrap();
                //have enemies move toward character
                foreach (Enemy c in grab)
                {
                    if (c.PosX < character.PosX)
                    {
                        c.PosX += 1;
                    }
                    else
                    {
                        c.PosX -= 1;
                    }
                    if (c.PosY < character.PosX)
                    {
                        c.PosY += 1;
                    }
                    else
                    {
                        c.PosY -= 1;
                    }
                }
                //check collsion and react
                if (cState == CharacterState.Action)
                {
                    
                    foreach (Enemy c in grab)
                    {
                        if (c.CheckCollision(character) == true)
                        {
                            c.Active = false;
                            character.LevelScore++;
                            character.TotalScore++;
                        }
                        
                    }
                    if (wait > 50)
                    {
                        character.TotalScore--;
                        wait = 0;
                    }
                    wait++;
                }
                //int platformpos;
                foreach (Platform platform in platforms)                    
                {
                    //platformpos = platform.PosX+platform.Width();
                    if (platform.CheckCollision(character)==true)
                    {
                        jumpspeed = -1;
                    }
                }
                if (cState == CharacterState.Stand||cState==CharacterState.Action)
                {
                    for (int r = 0; r < 3;r++ )
                    {
                        //if (platforms[r].Intersects(character.Rec)==false)
                        //{
                         //   character.PosY += 2;
                        //}
                        
                    }
                }
                //end game when character hits enemy while not in action state
                if (cState!=CharacterState.Action)
                {
                    foreach (Enemy c in grab)
                    {
                        //in case of collision subtract lives and move character away from enemy
                        if (c.CheckCollision(character) == true)
                        {
                            lives--;
                            
                        }
                    }
                    if (lives == 0)
                    {
                        gState = GameState.GameOver;
                    }
                    
                }
                //move to next level when all collectables are collected
                if (character.LevelScore == grab.Count)
                {
                    NextLevel();
                }
            }
            //game over state
            if (gState == GameState.GameOver)
            {
                previousKbState = kbState;
                kbState = Keyboard.GetState();
                if(SingleKeyPress(Keys.Enter)==true)
                {
                    gState = GameState.Menu;
                }
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            if (gState == GameState.Menu)
            {
                //spriteBatch.Draw(bernBegin, bernStartRec, Color.White);
                spriteBatch.DrawString(font1, "The 9 Levels", new Vector2(GraphicsDevice.Viewport.Width /2, GraphicsDevice.Viewport.Width /2), Color.Red);
                spriteBatch.DrawString(font1, "Press enter to begin", new Vector2(GraphicsDevice.Viewport.Width / 2, (GraphicsDevice.Viewport.Width / 2)+30), Color.Red);
                spriteBatch.DrawString(font1, "How to play:", new Vector2(10, 10), Color.Red);
                spriteBatch.DrawString(font1, "W - Jump", new Vector2(10,40), Color.Red);
                spriteBatch.DrawString(font1, "A - Left", new Vector2(10, 60), Color.Red);
                spriteBatch.DrawString(font1, "D - Right", new Vector2(10, 80), Color.Red);
                spriteBatch.DrawString(font1, "Space - Swing sword*", new Vector2(10, 100), Color.Red);
                spriteBatch.DrawString(font1, "Defeat the demons using your sword", new Vector2(10, 140), Color.Red);
                spriteBatch.DrawString(font1, "*Holding down sword swing deducts points overtime", new Vector2(10, 160), Color.Red);
            }
            if (gState == GameState.Game)
            {
                //draw platforms
                spriteBatch.Draw(redRectangle, bottom, Color.White);
                if (level % 4 == 0)
                {
                    platforms[0].Draw(spriteBatch);
                    platforms[1].Draw(spriteBatch);
                }
                else if (level % 5 == 1)
                {
                    platforms[2].Draw(spriteBatch);
                    platforms[3].Draw(spriteBatch);
                }
                else if(level%5==2)
                {
                    platforms[4].Draw(spriteBatch);
                    platforms[5].Draw(spriteBatch);
                }
                else if(level%5==3)
                {
                    platforms[6].Draw(spriteBatch);
                    platforms[7].Draw(spriteBatch);
                }
                else
                {
                    platforms[8].Draw(spriteBatch);
                    platforms[9].Draw(spriteBatch);
                }
                platforms[2].Draw(spriteBatch);
                //spriteBatch.Draw(redRectangle, platforms[2], Color.White);
                //spriteBatch.Draw(background, recBackground, Color.White);
                if (cState == CharacterState.Stand||cState==CharacterState.Jump)
                {
                    character.Draw(spriteBatch);
                }
                if (cState == CharacterState.Action)
                {
                    character.DrawAction(spriteBatch);
                }
                foreach (Enemy c in grab)
                {
                    c.Draw(spriteBatch);
                }
                spriteBatch.DrawString(font1, "Level: " + level + "  Score: "+ character.TotalScore/*+ " Time: " +String.Format("{0:0.00}", (timer))*/, new Vector2(0.0f, 0.0f), Color.Red);
            }
            if (gState == GameState.GameOver)
            {
                //spriteBatch.Draw(bernGameOver, bernStartRec, Color.White);
                spriteBatch.DrawString(font1, "Game Over", new Vector2(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Width / 2), Color.Black);
                spriteBatch.DrawString(font1, "Level: "+ level + " Total Score: "+character.TotalScore, new Vector2(GraphicsDevice.Viewport.Width / 2, (GraphicsDevice.Viewport.Width / 2) + 30), Color.Red);
                spriteBatch.DrawString(font1,"Press Enter to return to the Main Menu", new Vector2(GraphicsDevice.Viewport.Width / 2, (GraphicsDevice.Viewport.Width / 2) + 50), Color.Red);
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }

        //method to set up next level
        public void NextLevel()
        {
            level++;
            lives = 3;
            timer = 15.0;
            wait = 0;
            character.LevelScore = 0;
            character.PosX = GraphicsDevice.Viewport.Width / 2;
            character.PosY = 350;
            grab.Clear();
            int numOfCollects = level * 2+1;
            Random rand2 = new Random();
            for (int k=0; k < numOfCollects; k++)
            {
                int locX = rand.Next(GraphicsDevice.Viewport.Width);
                int locY = rand2.Next(GraphicsDevice.Viewport.Height);
                Enemy collect = new Enemy(locX,locY,45,45);
                foreach (Enemy c in grab)
                {
                    if (c.CheckCollision(character) == true)
                    {
                        c.Active = false;
                        character.LevelScore++;
                        character.TotalScore++;
                    }
                }
                if (level % 3 == 0)
                {
                    collect.Texture = Content.Load<Texture2D>("demon");
                }
                else if (level % 3 == 1)
                {
                    collect.Texture = Content.Load<Texture2D>("demon_4");
                }
                else
                {
                    collect.Texture = Content.Load<Texture2D>("skel");
                }
                grab.Add(collect);
            }
        }
        //method to restart game
        public void ResetGame()
        {
            level = 0;
            character.TotalScore = 0;
            NextLevel();
        }
        //method to screen wrap
        public void ScreenWrap()
        {
            if (character.PosX > GraphicsDevice.Viewport.Width)
            {
                character.PosX = 0;
            }
           /* if (character.PosY > GraphicsDevice.Viewport.Height)
            {
                character.PosY=0;
            }*/
            if (character.PosX <0)
            {
                character.PosX = GraphicsDevice.Viewport.Width;
            }
           /* if (character.PosY <0)
            {
                character.PosY = GraphicsDevice.Viewport.Height;
            }*/
        }
        //method so that key doesn't go off multiple times
        public Boolean SingleKeyPress(Keys key)
        {
            
            if (kbState.IsKeyDown(key) && previousKbState.IsKeyUp(key))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
