﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stenstrom_HW2
{
    class Platform:GameObject
    {
        int wdth;
        //platform constuctor
        public Platform(int x, int y, int width, int height):base(x,y,width,height) 
        {
            wdth = width;
        }
        //check collsion
        public Boolean CheckCollision(GameObject go)
        {
            //if objects intersect collsion true else collsion false
            
                if (this.Rec.Intersects(go.Rec))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        public int Width()
        {
            return wdth;
        }
            
    }
}
