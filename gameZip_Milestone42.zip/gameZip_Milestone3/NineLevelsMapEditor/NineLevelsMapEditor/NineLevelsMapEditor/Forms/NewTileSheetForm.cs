﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NineLevelsMapEditor.Forms
{
    public partial class NewTileSheetForm : Form
    {
        // File name for tile sheet
        public string sheetFileName;

        // Tile dimensions
        public int tileHeight = 32;
        public int tileWidth = 32;

        public NewTileSheetForm()
        {
            InitializeComponent();
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            // Open file dialog by setting the initial directory
            openFileDialog1.InitialDirectory = @"C:\";

            // Title for dialog box
            openFileDialog1.Title = "Select a map file";
            openFileDialog1.FileName = "";

            // Set the filter for only text files
            openFileDialog1.Filter = "Image Files (*.png) | *.png";
            openFileDialog1.FilterIndex = 1;

            // Browse for tilesheet file
            if (openFileDialog1.ShowDialog() != System.Windows.Forms.DialogResult.Cancel)
            {
                sheetFileName = openFileDialog1.FileName;
            }
            else
            {
                sheetFileName = "";
            }

            // Set the text box to the appropriate text
            tileSheetText.Text = sheetFileName;
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            // Display okay dialogue result
            this.DialogResult = DialogResult.OK;
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            // Cancel input
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
