﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NineLevelsMapEditor.Forms
{
    public partial class NewMapForm : Form
    {
        // Map and tile dimensions, and map name
        public int mapHeight;
        public int mapWidth;
        public int tileHeight;
        public int tileWidth;
        public string mapName;

        public NewMapForm()
        {
            InitializeComponent();
        }

        private void okayButton_Click(object sender, EventArgs e)
        {
            // Get input from the form
            mapName = mapNameText.Text;
            mapHeight = Convert.ToInt32(mapHeightBox.Value);
            mapWidth = Convert.ToInt32(mapWidthBox.Value);
            tileHeight = Convert.ToInt32(tileHeightBox.Value);
            tileWidth = Convert.ToInt32(tileWidthBox.Value);

            // Set the dialog result to OK
            this.DialogResult = DialogResult.OK;
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            // Cancel input
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
