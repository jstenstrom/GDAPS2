﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NineLevelsMapEditor.GUI
{
    public class LoadTileButton:Button
    {
        // Declare an instance variable
        private bool clicked = false;

        // Constructor
        public LoadTileButton(Texture2D tex, Vector2 pos)
            : base(tex, pos)
        {

        }

        // Update clicked
        public override void Update()
        {
            clicked = base.clicked;
            base.Update();
        }

        // Load the tile sheet as a texture
        private Texture2D TextureFromFile(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            Texture2D tex = Texture2D.FromStream(Game1.graphics.GraphicsDevice, fs);
            fs.Close();
            return tex;
        }

        // Event for the button
        public override void Effect()
        {
            // Freeze the game
            Game1.state = State.FREEZE;

            // Create an instance of the tile sheet form
            Forms.NewTileSheetForm sheetForm = new Forms.NewTileSheetForm();
            sheetForm.ShowDialog();
 
            // Get the tile sheet if the okay button has been clicked
            if (sheetForm.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                Game1.tileHeight = sheetForm.tileHeight;
                Game1.tileWidth = sheetForm.tileWidth;
                Game1.tileSheetFileName = sheetForm.sheetFileName;
                base.prevClicked = false;

                try
                {
                    // Import the sheet as a texture
                    Game1.tileSheet = TextureFromFile(Game1.tileSheetFileName);
                    Game1.map.LoadTileSet(Game1.tileSheet);
                }
                catch
                {
                    // The file name may be empty or not exist
                    System.Windows.Forms.MessageBox.Show("There was an error loading the texture.");
                }

            }
            else
            {
                base.prevClicked = false;
            }

            //Unfreeze the game
            Game1.state = State.PLAY;

            base.Effect();
        }
    }
}
