﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NineLevelsMapEditor.GUI
{
    public class CollisionLayerButton:Button
    {
        // Declare an instance variable
        private bool clicked = false;

        // Constructor
        public CollisionLayerButton(Texture2D tex, Vector2 pos)
            : base(tex, pos)
        {

        }

        // Update clicked
        public override void Update()
        {
            clicked = base.clicked;
            base.Update();
        }

        // Event for the button
        public override void Effect()
        {
            // Set the drawable layer
            Game1.drawableLayer = 2;
            base.prevClicked = false;
            base.Effect();
        }
    }
}
