﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace NineLevelsMapEditor.GUI
{
    public class LoadMapButton:Button
    {
        // Declare an instance variable
        private bool clicked = false;

        // Constructor
        public LoadMapButton(Texture2D tex, Vector2 pos)
            : base(tex, pos)
        {

        }

        // Update clicked
        public override void Update()
        {
            clicked = base.clicked;
            base.Update();
        }

        // Event for the button
        public override void Effect()
        {
            // Freeze the game
            Game1.state = State.FREEZE;

            // Create and show the load map form
            Forms.LoadMapForm loadMap = new Forms.LoadMapForm();
            loadMap.ShowDialog();

            // Reset button
            base.prevClicked = false;

            // Unfreeze game
            Game1.state = State.PLAY;


            base.Effect();
        }
    }
}
